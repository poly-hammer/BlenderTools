### Minor Changes
* Added validation to ensure source rig has a scale of 1.
  * [601](https://github.com/EpicGamesExt/BlenderTools/issues/601)


## Tests Passing On
* Blender `3.5` (installed from blender.org)
